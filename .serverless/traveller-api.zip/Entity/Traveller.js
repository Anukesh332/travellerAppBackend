class Traveller{

    constructor (Traveller) {

    
        var SK,PK


        //PK = uuidv4()

        //SK=PK

        //this.PK = PK

        //this.SK =   SK;

        this.TravellerName = Traveller.TravellerName;

       // this.CustId= SK

        this.TravellerGender = Traveller.TravellerGender

        this.TravellerDOB = Traveller.TravellerDOB

        this.Entity = "TRAVELLER"

        this.TravellerCode = Traveller.TravellerCode

        this.TravellerNumbaer = Traveller.TravellerNumber
        
        this.ValidDate=Traveller.ValidDate

        this.TravellerMail=Traveller.TravellerMail



        this.BookingId="Not Applicable"

    }



}



module.exports = {Traveller}